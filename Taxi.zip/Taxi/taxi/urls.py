"""
URL configuration for taxi project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path

from core.views import (
    admin_password_reset,
    admin_password_reset_new,
    admin_password_reset_verify,
    customer_password_reset,
    customer_password_reset_new,
    customer_password_reset_verify,
    driver_delete,
    driver_detail,
    driver_list,
    home,
    register_admin,
    register_user,
    user_delete,
    user_dashboard,
    user_detail,
    user_edit,
    user_login,
    user_logout,
    user_list,
)

urlpatterns = [
    path('', home, name='home'),
    path('register/', register_user, name='user_register'),
    path('login/', user_login, name='user_login'),
    path(
        'password-reset/',
        customer_password_reset,
        name='user_password_reset',
    ),
    path(
        'password-reset/done/',
        auth_views.PasswordResetDoneView.as_view(
            template_name='admin/password_reset_done.html',
            extra_context={
                'reset_verify_url': 'user_password_reset_verify',
                'reset_login_url': 'user_login',
            },
        ),
        name='user_password_reset_done',
    ),
    path(
        'password-reset/verify/',
        customer_password_reset_verify,
        name='user_password_reset_verify',
    ),
    path(
        'password-reset/new-password/',
        customer_password_reset_new,
        name='user_password_reset_new',
    ),
    path(
        'password-reset/complete/',
        auth_views.PasswordResetCompleteView.as_view(
            template_name='admin/password_reset_complete.html',
            extra_context={'reset_login_url': 'user_login'},
        ),
        name='user_password_reset_complete',
    ),
    path('dashboard/', user_dashboard, name='user_dashboard'),
    path('logout/', user_logout, name='user_logout'),
    path('admin/drivers/', driver_list, name='admin_drivers'),
    path('admin/drivers/<int:driver_id>/delete/', driver_delete, name='admin_driver_delete'),
    path('admin/drivers/<int:driver_id>/', driver_detail, name='admin_driver_detail'),
    path('admin/users/', user_list, name='admin_users'),
    path('admin/users/<int:user_id>/', user_detail, name='admin_user_detail'),
    path('admin/users/<int:user_id>/edit/', user_edit, name='admin_user_edit'),
    path('admin/users/<int:user_id>/delete/', user_delete, name='admin_user_delete'),
    path('admin/register/', register_admin, name='admin_register'),
    path(
        'admin/password-reset/',
        admin_password_reset,
        name='admin_password_reset',
    ),
    path(
        'admin/password-reset/done/',
        auth_views.PasswordResetDoneView.as_view(
            template_name='admin/password_reset_done.html',
        ),
        name='admin_password_reset_done',
    ),
    path(
        'admin/password-reset/verify/',
        admin_password_reset_verify,
        name='admin_password_reset_verify',
    ),
    path(
        'admin/password-reset/new-password/',
        admin_password_reset_new,
        name='admin_password_reset_new',
    ),
    path(
        'admin/password-reset/complete/',
        auth_views.PasswordResetCompleteView.as_view(
            template_name='admin/password_reset_complete.html',
        ),
        name='admin_password_reset_complete',
    ),
    path('admin/', admin.site.urls),
]
