from django.contrib.auth import get_user_model
from django.contrib.auth.backends import BaseBackend
from django.contrib.auth.backends import ModelBackend

from .models import User


class CustomerModelBackend(BaseBackend):
    def authenticate(self, request, email=None, password=None, **kwargs):
        if email is None or password is None:
            return None

        user = User.objects.filter(email__iexact=email).first()
        if user is not None and user.is_active and user.check_password(password):
            return user
        return None

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None


class EmailOrUsernameModelBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        if username is None:
            username = kwargs.get(get_user_model().USERNAME_FIELD)
        if username is None or password is None:
            return None

        user_model = get_user_model()
        try:
            user = user_model.objects.get(email__iexact=username)
        except user_model.DoesNotExist:
            return super().authenticate(request, username=username, password=password)
        except user_model.MultipleObjectsReturned:
            return None

        return super().authenticate(
            request,
            username=user.get_username(),
            password=password,
        )
