from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.contrib.auth.hashers import check_password, make_password
from django.db import models


class AdminUser(AbstractUser):
    phone = models.CharField(max_length=20, blank=True)

    class Meta:
        db_table = "core_admin"


class UserManager(BaseUserManager):
    def create_user(self, name, email, mobile, password):
        user = self.model(
            name=name,
            email=self.normalize_email(email),
            mobile=mobile,
        )
        user.set_password(password)
        user.save(using=self._db)
        return user


class User(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    mobile = models.CharField(max_length=20)
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)

    objects = UserManager()

    @property
    def is_authenticated(self):
        return True

    @property
    def is_anonymous(self):
        return False

    @property
    def is_active(self):
        return True

    @property
    def is_staff(self):
        return False

    @property
    def is_superuser(self):
        return False

    def get_username(self):
        return self.email

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return self.name


class Driver(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    license_number = models.CharField(max_length=50, unique=True)
    mobile = models.CharField(max_length=20)
    password = models.CharField(max_length=128)

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return self.name
